# MOTOYA — compilación en la nube desde Android

Este proyecto está preparado para compilar el APK sin una laptop usando Codemagic.

## 1. Desde tu celular

1. Crea o abre un repositorio de GitHub.
2. Sube **todo el contenido de esta carpeta**, incluyendo `codemagic.yaml`.
3. Entra a Codemagic y conecta GitHub.
4. Selecciona el repositorio de MOTOYA.
5. Selecciona el workflow **MOTOYA Android APK**.
6. Inicia el build.
7. Cuando termine, descarga el archivo `.apk` de **Artifacts**.

## 2. Qué genera

El workflow genera un APK Android instalable en:

`app/build/app/outputs/flutter-apk/*.apk`

Se usa `flutter build apk --debug` para obtener un APK instalable sin tener que configurar todavía una firma de publicación. Para publicar en Google Play posteriormente habrá que configurar una clave de firma de Android.

## 3. Importante sobre el backend

El APK usa por defecto:

`http://10.0.2.2:3000`

Eso funciona para un backend ejecutándose en el ordenador anfitrión del emulador Android, **no para un teléfono físico**. Para que MOTOYA funcione completamente desde tu celular, el backend de `backend/` debe estar desplegado en Internet y luego hay que cambiar `MOTOYA_API` en Codemagic por la URL HTTPS real del backend.

La API Key de OpenAI debe permanecer únicamente en el backend como variable `OPENAI_API_KEY`; nunca debe incluirse en Flutter ni en el APK.

## 4. No uses la API Key que se pegó en el chat

Esa clave debe considerarse expuesta. Revócala y crea una nueva antes de desplegar el backend.

#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/app"
flutter create .
flutter pub get

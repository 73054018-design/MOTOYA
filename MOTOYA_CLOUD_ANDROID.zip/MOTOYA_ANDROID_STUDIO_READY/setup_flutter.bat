@echo off
cd /d "%~dp0app"
flutter create .
flutter pub get
pause

# MOTOYA — Android Studio / Flutter

## 1. Requisitos
- Flutter SDK estable instalado y agregado al PATH.
- Android Studio estable con Android SDK.
- Dart/Flutter plugins habilitados.

Flutter recomienda verificar la instalación con `flutter doctor` y comprobar el dispositivo con `flutter devices`.

## 2. Preparar el proyecto
Desde la carpeta `app`:

```bash
flutter create .
flutter pub get
```

Esto genera/actualiza la carpeta `android/` con la plantilla compatible con la versión de Flutter instalada, conservando `lib/` y `pubspec.yaml` de MOTOYA.

## 3. Ejecutar
Con un teléfono Android conectado o un emulador:

```bash
flutter run --dart-define=MOTOYA_API=http://10.0.2.2:3000
```

En un teléfono físico, cambia `MOTOYA_API` por la IP LAN de la computadora donde corre el backend, por ejemplo `http://192.168.1.20:3000`.

## 4. Backend + OpenAI
Desde `backend`:

```bash
npm install
```

Copia `.env.example` como `.env` y configura:

```env
OPENAI_API_KEY=PEGA_TU_CLAVE_NUEVA_AQUI
OPENAI_MODEL=MODELO_COMPATIBLE
```

No coloques la API key dentro de Flutter, Dart, Git ni el APK. Debe permanecer en el servidor.

Luego:

```bash
node src/server.js
```

La API queda en `http://localhost:3000`.

## 5. Compilar APK
Desde `app`:

```bash
flutter build apk --release
```

Para APK separados por arquitectura:

```bash
flutter build apk --release --split-per-abi
```

El APK aparecerá bajo `build/app/outputs/flutter-apk/`.

## 6. Android Studio
Abre la carpeta `app` como proyecto Flutter. Si necesitas editar el módulo Android directamente, abre `app/android` en Android Studio.

## Seguridad
La clave que se compartió anteriormente en el chat debe considerarse comprometida. Revócala en OpenAI Platform y crea una nueva antes de usar MOTOYA.

# MOTOYA COMPLETE MVP
Plataforma de movilidad en moto: pasajero + conductor + administración.

## Incluido
- Flutter Android/Web
- API Node.js/Express
- Login demo por rol
- Solicitud/cotización de viajes
- Flujo conductor: disponibilidad, aceptar, iniciar con PIN, finalizar
- Historial y calificaciones
- GPS simulado para desarrollo
- Endpoint de ubicación
- Emergencia/protocolo
- Panel admin web estático
- Estructura preparada para PostgreSQL, Redis, mapas, pagos y notificaciones

## Ejecutar backend
cd backend
npm install
npm start

## Ejecutar app
cd app
flutter pub get
flutter run -d chrome
# Android: flutter run

## Admin
Abrir admin/index.html en un navegador.

Este producto es un prototipo tecnológico. Antes de operar transporte de pasajeros, deben verificarse y cumplirse las autorizaciones, seguros, requisitos del vehículo/conductor, protección de datos y demás normativa aplicable.


## OpenAI
El asistente IA usa la Responses API desde el backend. Configura `OPENAI_API_KEY` como variable de entorno; nunca pongas la clave dentro de Flutter ni la subas al repositorio.

Backend: `OPENAI_API_KEY=... OPENAI_MODEL=gpt-5.6-luna npm start`

Android Emulator: Flutter usa `http://10.0.2.2:3000` por defecto. Para otra URL: `flutter run --dart-define=MOTOYA_API=https://tu-servidor`.

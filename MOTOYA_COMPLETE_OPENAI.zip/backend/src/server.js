const express=require('express'),cors=require('cors');
const app=express(); app.use(cors()); app.use(express.json());
const drivers=[{id:'d1',name:'Carlos',rating:4.9,vehicle:'Honda GL 125',plate:'ABC-123',available:true,lat:-12.068,lon:-75.210}];
const users=[{id:'p1',name:'Pasajero Demo',role:'passenger'}];
const rides=[];
const ratings=[];
const incidents=[];
const price=(km,min)=>Number(Math.max(5,2.5+km*.9+min*.1).toFixed(2));
const id=(p,a)=>p+(a.length+1);

app.post('/api/ai/chat',async(q,r)=>{
  try{
    const apiKey=process.env.OPENAI_API_KEY;
    if(!apiKey)return r.status(503).json({error:'OPENAI_API_KEY no configurada en el servidor'});
    const message=String(q.body.message||'').trim();
    if(!message)return r.status(400).json({error:'Mensaje requerido'});
    const response=await fetch('https://api.openai.com/v1/responses',{
      method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${apiKey}`},
      body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-5.6-luna',input:`Eres el asistente de MOTOYA, una app peruana de movilidad en moto. Responde en español, de forma breve, útil y segura. No inventes tarifas, conductores ni estados de viajes.

Usuario: ${message}`})
    });
    const data=await response.json();
    if(!response.ok)return r.status(response.status).json({error:data.error?.message||'Error de OpenAI'});
    r.json({reply:data.output_text||''});
  }catch(e){r.status(500).json({error:'No se pudo contactar con OpenAI'});}
});

app.get('/api/health',(_,r)=>r.json({ok:true,app:'MOTOYA',version:'0.3'}));
app.post('/api/auth/demo',(q,r)=>{const role=q.body.role==='driver'?'driver':'passenger';r.json({token:'demo-token-'+role,user:{id:role==='driver'?'d1':'p1',name:role==='driver'?'Carlos':'Pasajero Demo',role}})});
app.get('/api/drivers',(q,r)=>r.json(drivers));
app.post('/api/drivers/:id/availability',(q,r)=>{const d=drivers.find(x=>x.id===q.params.id);if(!d)return r.status(404).json({error:'Conductor no encontrado'});d.available=!!q.body.available;r.json(d)});
app.post('/api/drivers/:id/location',(q,r)=>{const d=drivers.find(x=>x.id===q.params.id);if(!d)return r.status(404).json({error:'Conductor no encontrado'});d.lat=Number(q.body.lat);d.lon=Number(q.body.lon);d.locationAt=new Date().toISOString();r.json(d)});
app.post('/api/rides/quote',(q,r)=>r.json({price:price(q.body.distanceKm||0,q.body.durationMin||0),currency:'PEN'}));
app.post('/api/rides',(q,r)=>{const b=q.body;const ride={id:id('r',rides),passengerId:b.passengerId||'p1',driverId:null,origin:b.origin,destination:b.destination,distanceKm:Number(b.distanceKm||4.2),durationMin:Number(b.durationMin||14),estimatedPrice:price(b.distanceKm||4.2,b.durationMin||14),status:'requested',pin:String(Math.floor(1000+Math.random()*9000)),createdAt:new Date().toISOString()};rides.push(ride);r.status(201).json(ride)});
app.get('/api/rides',(q,r)=>r.json(rides));
app.post('/api/rides/:id/accept',(q,r)=>{const x=rides.find(x=>x.id===q.params.id);if(!x)return r.status(404).json({error:'Viaje no encontrado'});x.driverId=q.body.driverId||'d1';x.status='accepted';r.json(x)});
app.post('/api/rides/:id/start',(q,r)=>{const x=rides.find(x=>x.id===q.params.id);if(!x)return r.status(404).json({error:'Viaje no encontrado'});if(String(q.body.pin)!==x.pin)return r.status(400).json({error:'PIN incorrecto'});x.status='in_progress';x.startedAt=new Date().toISOString();r.json(x)});
app.post('/api/rides/:id/finish',(q,r)=>{const x=rides.find(x=>x.id===q.params.id);if(!x)return r.status(404).json({error:'Viaje no encontrado'});x.status='completed';x.completedAt=new Date().toISOString();r.json(x)});
app.post('/api/rides/:id/cancel',(q,r)=>{const x=rides.find(x=>x.id===q.params.id);if(!x)return r.status(404).json({error:'Viaje no encontrado'});x.status='cancelled';r.json(x)});
app.post('/api/rides/:id/rating',(q,r)=>{ratings.push({rideId:q.params.id,score:Number(q.body.score),comment:q.body.comment||'',createdAt:new Date().toISOString()});r.status(201).json({ok:true})});
app.post('/api/incidents',(q,r)=>{const x={id:id('i',incidents),rideId:q.body.rideId||null,type:q.body.type||'emergency',note:q.body.note||'',createdAt:new Date().toISOString()};incidents.push(x);r.status(201).json(x)});
app.get('/api/admin/summary',(q,r)=>r.json({users:users.length,drivers:drivers.length,riders:users.filter(x=>x.role==='passenger').length,rides:rides.length,completed:rides.filter(x=>x.status==='completed').length,incidents:incidents.length,ratings:ratings.length}));
app.listen(3000,()=>console.log('MOTOYA API http://localhost:3000'));

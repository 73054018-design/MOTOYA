import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const api=String.fromEnvironment('MOTOYA_API',defaultValue:'http://10.0.2.2:3000');

void main()=>runApp(const Motoya());

class Motoya extends StatelessWidget{
 const Motoya({super.key});
 Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,title:'MOTOYA',
 theme:ThemeData(useMaterial3:true,colorSchemeSeed:Colors.black),home:const Home());
}

class Home extends StatelessWidget{
 const Home({super.key});
 Widget build(BuildContext c)=>Scaffold(body:Center(child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:560),
 child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
 const Text('MOTOYA',style:TextStyle(fontSize:42,fontWeight:FontWeight.w900)),
 const Text('Muévete rápido. Muévete seguro.'),const SizedBox(height:35),
 _btn(c,'PASAJERO',Icons.person,()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const Passenger()))),
 const SizedBox(height:12),_btn(c,'CONDUCTOR',Icons.two_wheeler,()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const Driver()))),
 const SizedBox(height:12),_btn(c,'ASISTENTE MOTOYA',Icons.smart_toy,()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const Assistant()))),
 ]))));
 }
 Widget _btn(BuildContext c,String t,IconData i,VoidCallback f)=>SizedBox(width:double.infinity,height:54,child:FilledButton.icon(onPressed:f,icon:Icon(i),label:Text(t)));
}

class Passenger extends StatefulWidget{const Passenger({super.key});State<Passenger> createState()=>_PassengerState();}
class _PassengerState extends State<Passenger>{
 final o=TextEditingController(text:'Mi ubicación'),d=TextEditingController();
 double? fare;Map<String,dynamic>? ride;bool busy=false;
 Future<void> quote()async{final r=await http.post(Uri.parse('$api/api/rides/quote'),headers:{'Content-Type':'application/json'},body:jsonEncode({'distanceKm':4.2,'durationMin':14}));if(r.statusCode==200)setState(()=>fare=(jsonDecode(r.body)['price'] as num).toDouble());}
 Future<void> request()async{if(d.text.trim().isEmpty)return;setState(()=>busy=true);final r=await http.post(Uri.parse('$api/api/rides'),headers:{'Content-Type':'application/json'},body:jsonEncode({'origin':o.text,'destination':d.text,'distanceKm':4.2,'durationMin':14}));if(r.statusCode==201)setState(()=>ride=jsonDecode(r.body));setState(()=>busy=false);}
 Future<void> emergency()async{await http.post(Uri.parse('$api/api/incidents'),headers:{'Content-Type':'application/json'},body:jsonEncode({'rideId':ride?['id'],'type':'emergency','note':'Botón de emergencia activado'}));if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Incidente registrado')));}
 Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('MOTOYA · Pasajero')),body:ListView(padding:const EdgeInsets.all(20),children:[
 const Text('Solicitar viaje',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),const SizedBox(height:18),
 TextField(controller:o,decoration:const InputDecoration(labelText:'Origen',border:OutlineInputBorder(),prefixIcon:Icon(Icons.location_on))),
 const SizedBox(height:10),TextField(controller:d,decoration:const InputDecoration(labelText:'Destino',border:OutlineInputBorder(),prefixIcon:Icon(Icons.flag))),
 const SizedBox(height:15),Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
 const Text('🏍️ Moto',style:TextStyle(fontWeight:FontWeight.bold)),Text(fare==null?'Tarifa no calculada':'S/ ${fare!.toStringAsFixed(2)}'),
 const SizedBox(height:10),Row(children:[Expanded(child:OutlinedButton(onPressed:quote,child:const Text('CALCULAR'))),const SizedBox(width:8),Expanded(child:FilledButton(onPressed:busy?null:request,child:Text(busy?'...':'SOLICITAR')))])
 ]))),
 if(ride!=null)Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
 Text('Viaje ${ride!['id']}',style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),Text('Estado: ${ride!['status']}'),
 const SizedBox(height:8),Text('PIN de inicio: ${ride!['pin']}',style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),Text('Precio: S/ ${ride!['estimatedPrice']}'),
 ]))),
 const SizedBox(height:20),FilledButton.tonalIcon(onPressed:emergency,icon:const Icon(Icons.emergency),label:const Text('EMERGENCIA'))
 ]));
}
}

class Driver extends StatefulWidget{const Driver({super.key});State<Driver> createState()=>_DriverState();}
class _DriverState extends State<Driver>{
 bool online=false;List rides=[];Map<String,dynamic>? active;final pin=TextEditingController();
 Future<void> refresh()async{final r=await http.get(Uri.parse('$api/api/rides'));if(r.statusCode==200)setState(()=>rides=jsonDecode(r.body));}
 Future<void> availability(bool v)async{await http.post(Uri.parse('$api/api/drivers/d1/availability'),headers:{'Content-Type':'application/json'},body:jsonEncode({'available':v}));setState(()=>online=v);}
 Future<void> accept(String id)async{final r=await http.post(Uri.parse('$api/api/rides/$id/accept'),headers:{'Content-Type':'application/json'},body:jsonEncode({'driverId':'d1'}));if(r.statusCode==200)setState(()=>active=jsonDecode(r.body));}
 Future<void> start()async{if(active==null)return;final r=await http.post(Uri.parse('$api/api/rides/${active!['id']}/start'),headers:{'Content-Type':'application/json'},body:jsonEncode({'pin':pin.text}));if(r.statusCode==200)setState(()=>active=jsonDecode(r.body));else if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('PIN incorrecto')));}
 Future<void> finish()async{if(active==null)return;final r=await http.post(Uri.parse('$api/api/rides/${active!['id']}/finish'));if(r.statusCode==200)setState(()=>active=jsonDecode(r.body));}
 Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('MOTOYA · Conductor'),actions:[Switch(value:online,onChanged:availability)]),body:RefreshIndicator(onRefresh:refresh,child:ListView(padding:const EdgeInsets.all(20),children:[
 Card(child:ListTile(leading:Icon(online?Icons.circle:Icons.circle_outlined),title:Text(online?'EN LÍNEA':'OFFLINE'),subtitle:const Text('Disponibilidad del conductor'))),
 if(active!=null)Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
 Text('Viaje ${active!['id']} · ${active!['status']}'),Text('${active!['origin']} → ${active!['destination']}'),Text('S/ ${active!['estimatedPrice']}'),
 const SizedBox(height:10),TextField(controller:pin,decoration:const InputDecoration(labelText:'PIN del pasajero',border:OutlineInputBorder())),
 const SizedBox(height:8),Row(children:[Expanded(child:FilledButton(onPressed:start,child:const Text('INICIAR'))),const SizedBox(width:8),Expanded(child:OutlinedButton(onPressed:finish,child:const Text('FINALIZAR')))])
 ]))),
 const SizedBox(height:12),const Text('Solicitudes',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
 ...rides.where((r)=>r['status']=='requested').map((r)=>Card(child:ListTile(title:Text('${r['origin']} → ${r['destination']}'),subtitle:Text('S/ ${r['estimatedPrice']}'),trailing:FilledButton(onPressed:()=>accept(r['id']),child:const Text('ACEPTAR')))))
 ])));
}
}


class Assistant extends StatefulWidget{const Assistant({super.key});State<Assistant> createState()=>_AssistantState();}
class _AssistantState extends State<Assistant>{
 final input=TextEditingController();final messages=<Map<String,String>>[];bool busy=false;
 Future<void> send()async{final text=input.text.trim();if(text.isEmpty||busy)return;setState((){messages.add({'who':'Tú','text':text});input.clear();busy=true;});
  try{final r=await http.post(Uri.parse('$api/api/ai/chat'),headers:{'Content-Type':'application/json'},body:jsonEncode({'message':text}));final data=jsonDecode(r.body);setState(()=>messages.add({'who':'MOTOYA IA','text':r.statusCode==200?(data['reply']??'Sin respuesta'):('Error: ${data['error']??'No disponible'}')}));}
  catch(_){setState(()=>messages.add({'who':'MOTOYA IA','text':'No se pudo conectar con el servidor.'}));}finally{if(mounted)setState(()=>busy=false);}}
 Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('MOTOYA · Asistente IA')),body:Column(children:[
  Expanded(child:ListView(padding:const EdgeInsets.all(16),children:[const Card(child:Padding(padding:EdgeInsets.all(14),child:Text('Puedo ayudarte con información de MOTOYA, viajes, seguridad y uso de la aplicación.'))),...messages.map((m)=>Align(alignment:m['who']=='Tú'?Alignment.centerRight:Alignment.centerLeft,child:Card(child:Padding(padding:const EdgeInsets.all(12),child:Text('${m['who']}:\n${m['text']}')))))])),
  Padding(padding:const EdgeInsets.all(12),child:Row(children:[Expanded(child:TextField(controller:input,onSubmitted:(_)=>send(),decoration:const InputDecoration(hintText:'Escribe tu pregunta...',border:OutlineInputBorder()))),const SizedBox(width:8),IconButton.filled(onPressed:busy?null:send,icon:const Icon(Icons.send))]))
 ]));
}

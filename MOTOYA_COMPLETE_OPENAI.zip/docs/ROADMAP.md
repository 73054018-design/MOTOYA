# Roadmap de producción
1. Auth real: OTP/SMS, JWT, refresh tokens, recuperación de cuenta.
2. PostgreSQL: usuarios, documentos, vehículos, viajes, pagos, ratings, incidentes.
3. Redis + WebSockets: ubicación en tiempo real y dispatch.
4. Mapas: proveedor de mapas/routing y geocoding.
5. Pagos: proveedor con tokenización.
6. Notificaciones push.
7. Verificación de identidad y documentos.
8. Panel admin con roles, auditoría y moderación.
9. Seguridad: TLS, RBAC, MFA admin, rate limiting, antifraude, logs.
10. Privacidad: minimización, retención, derechos de titulares y política de privacidad.
11. QA: pruebas unitarias, integración, carga y seguridad.
12. Operación: términos, seguros, soporte y validación regulatoria antes de lanzar transporte.

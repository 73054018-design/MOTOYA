# Arquitectura
Flutter Android/Web
  -> API Gateway
  -> Auth / Users
  -> Ride Service
  -> Dispatch Service
  -> Pricing Service
  -> Safety / Incident Service
  -> Payments
  -> Notifications
  -> PostgreSQL
  -> Redis
  -> Maps/Routing

Admin web -> API con RBAC.

El MVP actual usa Express y memoria para poder ejecutarse sin servicios externos. Las interfaces ya están separadas para migrar a servicios de producción.
